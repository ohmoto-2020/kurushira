@extends('common')
@section('title','ホーム | クルシラ')
<body class="home-body">
@section('content')

<h1>これはメインです</h1>

@endsection
