@extends('common')
@section('title','サイト詳細 | クルシラ')
<body class="body">
@section('content')
<div class="container">
  <h2>これはサイト詳細です</h2>
</div>

@endsection
