<h1 class="header__left"><a href="<?php echo e(url('/')); ?>">クルシラ</a></h1>
<?php if(Route::has('login')): ?>
<div class="header__right">
<?php if(auth()->guard()->check()): ?>
  <a href="<?php echo e(url('/myPage')); ?>">マイページ</a>
  <!-- <a href="<?php echo e(route('logout')); ?>">ログアウト</a> -->
  <form class="logout" action="<?php echo e(route('logout')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input class="logout__button" type="submit" value='ログアウト'>
  </form>
<?php else: ?>
  <a href="<?php echo e(route('login')); ?>">ログイン</a>

  <?php if(Route::has('register')): ?>
  <a href="<?php echo e(route('register')); ?>">ユーザー登録</a>
  <?php endif; ?>
<?php endif; ?>
<?php endif; ?>
  <a href="<?php echo e(route('about')); ?>">サイト詳細</a>
</div>
<?php /**PATH /var/www/html/laravel/resources/views/layouts/header.blade.php ENDPATH**/ ?>