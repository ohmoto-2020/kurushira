
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <header>
       <h1>これはheaderです</h1>
    </header>
    <main>
        <div>
            <?php echo $__env->yieldContent(''); ?>
        </div>
    <footer>
        <h1>これはfooterです</h1>
    </footer>
    </main>
</body>
</html>
<?php /**PATH /var/www/html/laravel/resources/views/layouts/index.blade.php ENDPATH**/ ?>