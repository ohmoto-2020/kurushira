<?php $__env->startSection('title','サイト詳細 | クルシラ'); ?>
<body class="body">
<?php $__env->startSection('content'); ?>
<div class="container">
  <h1>これはサイト詳細です</h1>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/resources/views/star/about.blade.php ENDPATH**/ ?>