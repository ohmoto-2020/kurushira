<?php $__env->startSection('title','ホーム | クルシラ'); ?>
<body class="home-body">
<?php $__env->startSection('content'); ?>

<h1>これはメインです</h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/resources/views/star/index.blade.php ENDPATH**/ ?>