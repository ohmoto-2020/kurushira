<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <header>
      <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>
    <main>
      <div>
        <h1>これはメインです</h1>
      </div>
    <footer>
      <h1>これはfooterです</h1>
    </footer>
    </main>
</body>
</html>
<?php /**PATH /var/www/html/laravel/resources/views/index.blade.php ENDPATH**/ ?>